package AnnotationEg;

public interface Animal {
    void sound();
}
